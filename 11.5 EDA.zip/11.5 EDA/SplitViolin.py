import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
import PlotTools

savefilename = 'UNET_SVP.png'
sns.set(style="whitegrid", palette="pastel", color_codes=True)

# Load the example tips dataset
df = pd.read_csv('UNET_SVP.csv')

tips = df

# Draw a nested violinplot and split the violins for easier comparison
sns.violinplot(x="Method", y="Size (nm)", hue="Approach", data=tips, split=True,
               inner="quart", palette={'Automated': "b", 'Manual': "orange"})
sns.despine(left=True)
plt.ylim(0.00, 40)
plt.title('UNET PSD')
PlotTools.axis_square()
plt.savefig(savefilename, dpi=600)
