# -*- coding: utf-8 -*-
"""
Created on Mon Jan 20 12:23:05 2020

@author: Daniel Groom
"""
importfilename1 = 'UNET_Iso2.csv'
savefilename = 'UNET_Iso2.png'

# =============================================================================
# End User Inputs
# =============================================================================
import PlotTools
import numpy as np
import matplotlib.pyplot as plt
import csv
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
#xlabel = 'Binarization Algorithm'
#ylabel = 'JSC'
#title = 'Binarization Violin Plots'
#xticklabels = ['Multi Scale','Single Scale','Global']
xticklabelrotation = 0
df = pd.read_csv(importfilename1)

tips = df
pkmn_type_colors = [
                    '#6890F0',  # Water
                    '#F08030',  # Fire
                    '#C0C0C0',  # Grey
                    '#ffd343',  # Yellow
                    '#58ff42',  # Green
                    '#F8D030',  # Electric
                    '#E0C068',  # Ground
                    '#EE99AC',  # Fairy
                    '#C03028',  # Fighting
                    '#F85888',  # Psychic
                    '#B8A038',  # Rock
                    '#705898',  # Ghost
                    '#98D8D8',  # Ice
                    '#7038F8',  # Dragon
                   ]
# Draw a nested violinplot and split the violins for easier comparison

sns.violinplot(x='Method',
               y='JSC', 
               data=df, 
               inner=None, # Remove the bars inside the violins
               palette=pkmn_type_colors)
 
sns.swarmplot(x='Method', 
              y='JSC', 
              data=df, 
              color='k', # Make points black
              alpha=0.7) # and sligh
plt.ylim(0.00, 1.1)
PlotTools.axis_square()
plt.savefig(savefilename, dpi=600)

